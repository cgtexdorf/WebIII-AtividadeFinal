CREATE DATABASE IF NOT EXISTS IFPRLibrary;

USE IFPRLibrary;

CREATE TABLE IF NOT EXISTS author (
id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS book (
id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(255) NOT NULL,
date DATE NOT NULL,
author_id INT,
status VARCHAR(50) NOT NULL,
FOREIGN KEY (author_id) REFERENCES author(id)
);

INSERT INTO author (name) VALUES
('J.K. Rowling'),
('George R.R. Martin'),
('J.R.R. Tolkien'),
('Agatha Christie'),
('Isaac Asimov');

INSERT INTO book (name, date, author_id, status) VALUES
('Harry Potter and the Philosopher\'s Stone', '1997-06-26', 1, 'Disponivel'),
('A Game of Thrones', '1996-08-06', 2, 'Indisponivel'),
('The Hobbit', '1937-09-21', 3, 'Reservado'),
('Murder on the Orient Express', '1934-01-01', 4, 'Disponivel'),
('Foundation', '1951-06-01', 5, 'Disponivel');
