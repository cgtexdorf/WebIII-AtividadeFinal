package br.edu.ifpr.foz.ifprlibrary.models;

public enum BookStatus {
    Disponivel("Disponivel"),
    Indisponivel("Indisponivel"),
    Reservado("Reservado");

    private String status;

    private BookStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }


}
