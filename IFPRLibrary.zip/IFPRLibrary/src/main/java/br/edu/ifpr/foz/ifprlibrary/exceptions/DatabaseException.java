package br.edu.ifpr.foz.ifprlibrary.exceptions;

//não chechada
public class DatabaseException extends RuntimeException {

    public DatabaseException(String msg){
        super(msg);
    }

}
