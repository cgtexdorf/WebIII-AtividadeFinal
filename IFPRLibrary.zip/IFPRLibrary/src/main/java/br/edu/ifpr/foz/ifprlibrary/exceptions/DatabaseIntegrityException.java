package br.edu.ifpr.foz.ifprlibrary.exceptions;

//não chechada
public class DatabaseIntegrityException extends RuntimeException {

    public DatabaseIntegrityException(String msg){
        super(msg);
    }

}
